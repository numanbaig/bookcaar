export const opacityColors = () => {
  return {
    z1: "rgba(240, 90, 40, 0.1)",
    primary: "rgba(84, 214, 44, 0.24)",
    lightHover: "rgba(145, 158, 171, 0.08)",
    borderColor: "rgba(145, 158, 171, 0.32)",
  }
}
